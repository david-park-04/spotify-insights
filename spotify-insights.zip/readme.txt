How to run the Spotify Insights application.

Instructions: 

Given that you have all the necessary files...

- Navigate to the 'spotify-insights-client' folder

- Run 'chmod 755 *.bash'

- ./docker-build.bash
- ./docker-run.bash

- python3 main.py  

