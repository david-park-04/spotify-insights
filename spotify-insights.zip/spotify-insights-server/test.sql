-- Testing users --
USE spotify;

SELECT * FROM tokens;